<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<form class="mt-2 ml-2" method="get" action="/taber/grup">
    <button type="submit" class="btn btn-info"> Kembali </button>
</form>
<h1>HAlaman Join</h1>
<?= $this->endSection('content'); ?>