<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col mt-4">
            <h1>SISTEM TABUNGAN BERSAMA</h1>
        </div>
    </div>
</div>

<!-- <div class="container">
    <button type="button" class="btn btn-success">Terima</button>
    <button type="button" class="btn btn-danger">Tolak</button>
</div> -->

<?= $this->endSection('content'); ?>